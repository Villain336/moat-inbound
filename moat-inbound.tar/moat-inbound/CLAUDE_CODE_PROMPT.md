# MOAT — AI Inbound Defense System
## Claude Code Master Build Prompt

You are building **Moat**, an AI-powered inbound defense system that protects executives and CEOs from cold email spam, automated outreach sequences, and AI agent-generated solicitations. The repo has been initialized with scaffolding, a Drizzle ORM schema, an AI classification engine, type definitions, and an interactive MVP prototype.

---

## PROJECT CONTEXT

**Problem:** CEOs and LinkedIn power users are drowning in automated outreach from tools like Apollo.io, Clay, GoHighLevel, Polsia, Instantly, Outreach.io, and SalesLoft. Every inbox is flooded with AI-generated, enrichment-fueled spam that wastes hours daily. The outreach arms race has created massive demand for the *defense* side.

**Solution:** Moat sits between the user's inbox (Gmail/Outlook) and the outside world. It classifies every inbound message using Claude, detects which sales tool sent it, and optionally deploys an AI "defense agent" that engages and qualifies inbound outreach (including other AI agents) before anything reaches the human.

**Brand:** Moat. Tagline: "Your AI chief of staff that intercepts, qualifies, and handles the outreach flood before it reaches you." Design language: dark (#09090b), monospace accents (IBM Plex Mono), clean display font (Outfit), accent colors — green (#34c759) for approved, red (#ff3b30) for blocked, orange (#ff9500) for intercepted, blue (#007aff) for agent activity, purple (#8b5cf6) for tool detection.

**Business model:** SaaS. Free tier (50 messages/month, basic classification). Pro $49/mo (unlimited, full agent, all rules). Executive $149/mo (multi-inbox, team, priority support). Enterprise custom.

---

## TECH STACK

- **Framework:** Next.js 14 (App Router, Server Components, Server Actions)
- **Language:** TypeScript (strict mode)
- **Styling:** Tailwind CSS + custom design tokens. Dark theme only.
- **Animations:** Framer Motion
- **Database:** Supabase (PostgreSQL) via Drizzle ORM
- **Auth:** NextAuth.js v4 with Google OAuth (for Gmail integration) and Microsoft OAuth (for Outlook)
- **AI Engine:** Anthropic Claude (claude-sonnet-4-20250514) via @anthropic-ai/sdk
- **Email Integration:** Gmail API (via Google OAuth), Microsoft Graph API (via MSAL)
- **Transactional Email:** Resend (for sending agent responses)
- **State Management:** Zustand (client-side state)
- **Deployment Target:** Vercel

---

## EXISTING FILES IN REPO

```
moat-inbound/
├── .env.example                          # All required env vars
├── .gitignore
├── README.md
├── drizzle.config.ts                     # Drizzle config → Supabase
├── next.config.js
├── package.json                          # All deps declared
├── postcss.config.js
├── tailwind.config.js                    # Custom moat theme tokens
├── tsconfig.json
├── src/
│   ├── app/
│   │   ├── globals.css                   # Tailwind + custom fonts
│   │   ├── layout.tsx                    # Root layout
│   │   └── page.tsx                      # Landing page placeholder
│   ├── components/
│   │   └── dashboard/
│   │       └── MoatDashboard.jsx         # *** INTERACTIVE MVP PROTOTYPE ***
│   ├── hooks/                            # Empty — build custom hooks here
│   ├── lib/
│   │   ├── ai/
│   │   │   └── classifier.ts            # *** CLAUDE CLASSIFICATION ENGINE ***
│   │   ├── db/
│   │   │   └── schema.ts               # *** FULL DRIZZLE SCHEMA (17 tables) ***
│   │   ├── integrations/                # Empty — build Gmail/Outlook connectors
│   │   └── supabase.ts                  # Supabase client init
│   └── types/
│       └── index.ts                     # All TypeScript interfaces
```

**CRITICAL:** The `MoatDashboard.jsx` file is a fully interactive prototype with all 5 tabs (Command Center, Inbound Feed, Defense Rules, Allow/Block Lists, Agent Config) using simulated data. Use it as the **design reference and feature spec** — every feature shown in that prototype must work with real data in the final build.

**CRITICAL:** The `schema.ts` has the full database model (users, connected_accounts, inbound_messages, agent_conversations, agent_messages, defense_rules, allowlist, blocklist, qualification_scripts, agent_capabilities, daily_stats, webhook_events). Use Drizzle ORM for all database operations.

**CRITICAL:** The `classifier.ts` has the Claude classification engine with the full prompt, fingerprinting logic, and agent response generator. Wire this into the message processing pipeline.

---

## BUILD PHASES

### PHASE 1: Core Infrastructure (Do First)

1. **Database Setup**
   - Run `npm run db:push` to create all tables in Supabase
   - Create `src/lib/db/index.ts` — Drizzle client instance connected to Supabase
   - Create `src/lib/db/queries.ts` — All database query functions:
     - `getInboundMessages(userId, filters)` with pagination, status filter, date range
     - `createInboundMessage(data)` 
     - `updateMessageStatus(messageId, status)`
     - `getDefenseRules(userId)`
     - `createDefenseRule(data)` / `updateDefenseRule(id, data)` / `toggleRule(id)`
     - `getAllowlist(userId)` / `addToAllowlist(userId, entry)` / `removeFromAllowlist(id)`
     - `getBlocklist(userId)` / `addToBlocklist(userId, entry)` / `removeFromBlocklist(id)`
     - `getDailyStats(userId, dateRange)`
     - `getAgentConversation(messageId)` / `addAgentMessage(conversationId, data)`
     - `getUserPreferences(userId)` / `updateUserPreferences(userId, data)`

2. **Authentication**
   - Set up NextAuth.js at `src/app/api/auth/[...nextauth]/route.ts`
   - Google OAuth provider (also gets Gmail access token)
   - Microsoft OAuth provider (Outlook access)
   - On first login: create user record, seed default defense rules, create default qualification script
   - Middleware at `src/middleware.ts` — protect `/dashboard/*` routes
   - Auth pages at `src/app/(auth)/login/page.tsx`

3. **Default Defense Rules (seed on signup)**
   - "Block Template Variables" — hard_block — condition: `body_contains_any(["{{", "{!", "<%="])`
   - "Apollo/Clay Fingerprint" — intercept — condition: `header_match(["apollo", "clay", "outreach"]) OR enrichment_signals`
   - "AI Agent Detection" — intercept — condition: `ai_patterns_score > 70`
   - "Sequence Detection" — hard_block — condition: `is_followup AND no_prior_engagement`
   - "VIP Allowlist" — approve — condition: `sender_domain IN allowlist`
   - "Domain Reputation" — intercept — condition: `domain_age < 90 OR spam_score > 60`

### PHASE 2: Email Integration Pipeline

4. **Gmail Integration** (`src/lib/integrations/gmail.ts`)
   - Use Gmail API with the OAuth token from NextAuth
   - `watchInbox(userId)` — Set up Gmail push notifications via Pub/Sub to webhook
   - `fetchNewMessages(userId, since)` — Pull new messages with full headers
   - `getMessageHeaders(message)` — Extract X-Mailer, List-Unsubscribe, tracking pixels
   - `markAsRead(messageId)` / `archiveMessage(messageId)` / `moveToFolder(messageId, folder)`
   - `sendReply(messageId, body)` — For agent responses via the user's Gmail

5. **Webhook Receiver** (`src/app/api/webhooks/gmail/route.ts`)
   - Receives Gmail push notifications when new mail arrives
   - Triggers the classification pipeline
   - Stores raw webhook event in `webhook_events` table

6. **Message Processing Pipeline** (`src/lib/ai/pipeline.ts`)
   - `processInboundMessage(userId, rawMessage)` — The main orchestration function:
     1. Parse email (sender, subject, body, headers)
     2. Check allowlist → if match, auto-approve, skip classification
     3. Check blocklist → if match, auto-block, skip classification
     4. Run defense rules engine → check all enabled rules against message
     5. Call `classifyMessage()` from classifier.ts → get Claude's analysis
     6. Compute final threat score (combine rule matches + AI score)
     7. Determine action: block / intercept / qualify / approve
     8. If intercept/qualify AND agent posture != passive → start agent conversation
     9. Save message to `inbound_messages` with full analysis
     10. Update `daily_stats`
     11. If approved → let message through (mark as read, leave in inbox)
     12. If blocked → archive/trash in Gmail, log
     13. If intercepted → hold, optionally start agent convo

7. **Tool Detection** (`src/lib/ai/tool-detector.ts`)
   - Header-based detection: known X-Mailer values, tracking pixel domains, unsubscribe link patterns
   - Known tool signatures:
     - Apollo.io: `apollo.io` tracking pixels, specific header patterns
     - Clay: enrichment data patterns in email body
     - GoHighLevel: `msgsndr.com` links, GHL tracking
     - Outreach.io: `outreach.io` tracking, specific sequence headers
     - Instantly: `instantly.ai` infrastructure
     - SalesLoft: `salesloft.com` tracking
     - Polsia: AI-generated personalization patterns
     - Lemlist: `lemlist.com` tracking
   - Body-based detection: template variable patterns, merge tag formats
   - Combine with Claude's analysis for final tool attribution

### PHASE 3: Dashboard (Convert Prototype to Production)

8. **Dashboard Layout** (`src/app/(dashboard)/layout.tsx`)
   - Server Component shell with sidebar navigation
   - Mirror the tab structure from MoatDashboard.jsx: Command Center, Inbound Feed, Defense Rules, Allow/Block Lists, Agent Config
   - Use Next.js App Router nested layouts
   - Header with Moat logo, active status indicator, user avatar dropdown

9. **Command Center** (`src/app/(dashboard)/page.tsx`)
   - Real-time stats cards (blocked, intercepted, approved, agent convos today)
   - Weekly volume stacked bar chart (use Recharts or replicate the CSS chart from prototype)
   - Outreach tools detected — horizontal bar chart with tool names and counts
   - Latest intercepts feed — clickable rows that link to message detail
   - All data fetched via Server Components from `getDailyStats()` and recent messages query

10. **Inbound Feed** (`src/app/(dashboard)/inbox/page.tsx`)
    - Filter bar: all | blocked | intercepted | agent_handling | approved
    - Message list with: channel icon, sender/company, subject, threat badge, status pill, tool tag, timestamp
    - Click to expand → detail panel (split view on desktop, full page on mobile)
    - Detail panel shows: full message preview, AI analysis breakdown, matched rules, agent actions
    - Action buttons: Approve, Block Domain, View Agent Conversation
    - Infinite scroll pagination
    - Real-time updates via Supabase realtime subscriptions (optional, nice-to-have)

11. **Defense Rules** (`src/app/(dashboard)/rules/page.tsx`)
    - List all rules with toggle switches, severity badges, trigger counts
    - Add new rule form: name, description, severity dropdown, conditions builder
    - Edit existing rules inline
    - System rules (seeded defaults) show lock icon, can be toggled but not deleted
    - Rule conditions stored as JSON — build a simple condition builder UI:
      - `body_contains_any(["string1", "string2"])` 
      - `header_match(["pattern1"])` 
      - `sender_domain_in(["domain1.com"])` 
      - `threat_score_above(threshold)` 
      - `classification_is(["spam", "automated_outreach"])`

12. **Allow/Block Lists** (`src/app/(dashboard)/lists/page.tsx`)
    - Two-column layout: Allowlist (green) | Blocklist (red)
    - Add entries by domain or email with enter key
    - Remove with × button
    - Show who/what added it (manual, agent, auto-block) and when
    - Bulk import via comma-separated text

13. **Agent Config** (`src/app/(dashboard)/agent/page.tsx`)
    - Agent Posture selector: Passive / Defensive / Aggressive — with descriptions
    - Capability toggles: Agent-to-Agent Negotiation, Linguistic Fingerprinting, Tool Signature Detection, Cross-Reference Verification, Auto-Unsubscribe, Honeypot Engagement
    - Qualification Script editor: reorderable list of questions, add/remove/edit
    - Preview mode: test the agent with a sample message

### PHASE 4: Agent Conversation System

14. **Agent Conversation Engine** (`src/lib/ai/agent.ts`)
    - When a message is intercepted and agent posture is defensive/aggressive:
      1. Auto-generate initial reply using `generateAgentResponse()` from classifier.ts
      2. Send reply via Gmail API (from user's account, as if their assistant replied)
      3. When inbound sender responds → new message hits webhook → detect it's a reply to agent thread
      4. Feed full conversation history to Claude → generate next response
      5. After qualification questions are answered (or sender fails to answer) → resolve:
         - Qualified → change status to `approved`, notify user
         - Disqualified → change status to `blocked`, archive thread
         - Escalated → change status to `agent_handling`, flag for user review
    - Thread detection: match by In-Reply-To / References headers

15. **Agent Conversation Viewer** (`src/components/dashboard/AgentConversation.tsx`)
    - Modal/slide-over that shows the full agent conversation
    - Messages styled differently: Moat Agent (green), Inbound Agent (orange), User Override (blue)
    - User can type to override/interject in the conversation
    - Show conversation outcome and agent reasoning
    - Mirror the `AgentConversation` component from the prototype

### PHASE 5: API Routes

16. **API Routes** (all under `src/app/api/`)
    ```
    POST /api/messages/classify      — Manual classify a message
    GET  /api/messages               — List messages with filters  
    PATCH /api/messages/[id]/status  — Update message status
    GET  /api/stats                  — Get dashboard stats
    GET  /api/rules                  — List defense rules
    POST /api/rules                  — Create rule
    PATCH /api/rules/[id]            — Update/toggle rule
    DELETE /api/rules/[id]           — Delete rule
    GET  /api/allowlist              — Get allowlist
    POST /api/allowlist              — Add entry
    DELETE /api/allowlist/[id]       — Remove entry
    GET  /api/blocklist              — Get blocklist
    POST /api/blocklist              — Add entry
    DELETE /api/blocklist/[id]       — Remove entry
    GET  /api/agent/conversations    — List conversations
    GET  /api/agent/conversations/[id] — Get conversation with messages
    POST /api/agent/conversations/[id]/reply — User override reply
    PATCH /api/agent/config          — Update agent posture/capabilities
    POST /api/webhooks/gmail         — Gmail push notification receiver
    POST /api/webhooks/outlook       — Outlook webhook receiver
    ```
    - All routes authenticate via NextAuth session
    - Use Server Actions for form mutations where appropriate
    - Return consistent JSON: `{ data, error, meta: { total, page } }`

### PHASE 6: Landing Page & Onboarding

17. **Landing Page** (`src/app/page.tsx`)
    - Hero: "Stop the Flood" — animated visualization of messages being intercepted
    - Problem statement with stats (avg exec gets 120+ cold emails/day)
    - Feature grid: Classification Engine, Agent Defense, Rules Engine, Tool Detection
    - Social proof section (placeholder)
    - Pricing: Free / Pro $49/mo / Executive $149/mo
    - CTA: "Protect Your Inbox" → sign up with Google
    - Design: match the dark, monospace-accented aesthetic of the dashboard

18. **Onboarding Flow** (`src/app/(dashboard)/onboarding/page.tsx`)
    - Step 1: Connect Gmail/Outlook (OAuth flow)
    - Step 2: Choose agent posture (Passive / Defensive / Aggressive)
    - Step 3: Seed allowlist (import from contacts, add key domains)
    - Step 4: Review default defense rules (toggle on/off)
    - Step 5: Done — redirect to Command Center

---

## CODE STANDARDS

- Use Server Components by default. Only use `"use client"` when state/interactivity is needed.
- Use Server Actions for form mutations instead of API routes where possible.
- All database queries go through the Drizzle query functions in `src/lib/db/queries.ts`.
- Use Zustand for client-side state (active filters, selected message, UI state).
- Error handling: wrap all async operations in try/catch, return typed error objects.
- Loading states: use React Suspense boundaries with skeleton loaders.
- All API routes validate input with Zod schemas.
- Use the design tokens from `tailwind.config.js` — never hardcode colors.
- Follow the design language from the prototype (dark bg, monospace labels, threat color coding).
- Mobile-responsive: the dashboard should work on mobile with a collapsible sidebar.

---

## IMPORTANT CONSTRAINTS

1. **Start with Phase 1 and 2 before touching the UI.** The backend pipeline is the product — the dashboard is just a view layer.
2. **The AI classifier prompt in `classifier.ts` is final.** Don't modify the prompt unless asked.
3. **Real email integration is critical for MVP.** Gmail first, Outlook second. Without reading actual emails, this product has no value.
4. **Agent conversations must use the user's actual Gmail** to send replies. The agent should appear to be the user's assistant, not a third-party bot.
5. **Deploy to Vercel.** Use edge functions for webhooks, serverless for API routes.
6. **Supabase for everything** — auth tokens, message storage, stats, conversations.

---

## FIRST TASK

Run `npm install`, then `npm run db:push` to create all tables. Then build out Phase 1 (database queries layer + auth). After auth works, move to Phase 2 (Gmail integration + classification pipeline). Once messages are flowing and being classified, convert the prototype dashboard to production with real data.
