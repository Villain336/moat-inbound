import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Moat — AI Inbound Defense System',
  description:
    'Your AI chief of staff that intercepts, qualifies, and handles the outreach flood before it reaches you.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
