import { useState, useEffect, useCallback, useRef } from "react";

const FONTS = `
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Outfit:wght@300;400;500;600;700;800&display=swap');
`;

// — Simulated Data —
const INBOUND_MESSAGES = [
  {
    id: 1,
    sender: "Kyle Branson",
    company: "ScaleAI Solutions",
    channel: "email",
    subject: "Quick question about your infrastructure needs",
    preview: "Hi, I noticed your company recently raised a Series B. We help companies like yours scale their AI infrastructure by 10x. Would love to grab 15 minutes...",
    timestamp: "2m ago",
    threat_score: 92,
    classification: "automated_outreach",
    tool_detected: "Apollo.io",
    status: "intercepted",
    agent_response: "Responded with qualification questions. Sender failed to provide specific context about our actual tech stack — confirmed automated sequence.",
  },
  {
    id: 2,
    sender: "Maria Chen",
    company: "Andreessen Horowitz",
    channel: "linkedin",
    subject: "Following up on the Founder Summit",
    preview: "Great meeting you at the event last week. I'd love to continue our conversation about the defense-tech thesis you mentioned...",
    timestamp: "14m ago",
    threat_score: 8,
    classification: "legitimate",
    tool_detected: null,
    status: "approved",
    agent_response: null,
  },
  {
    id: 3,
    sender: "James Whitfield",
    company: "LeadGen Pro",
    channel: "email",
    subject: "We guarantee 50 meetings/month",
    preview: "Hey {{first_name}}, I saw you're in the {{industry}} space. Our clients see 3-5x ROI within 30 days using our proprietary outreach system...",
    timestamp: "28m ago",
    threat_score: 99,
    classification: "spam",
    tool_detected: "GoHighLevel",
    status: "blocked",
    agent_response: "Template variables detected ({{first_name}}, {{industry}}). Auto-blocked. Sender domain added to permanent block list.",
  },
  {
    id: 4,
    sender: "Rachel Torres",
    company: "Meridian Capital",
    channel: "email",
    subject: "Co-investment opportunity — Series A in robotics",
    preview: "Our fund is leading a $12M Series A in a robotics company out of CMU. Given your portfolio focus, thought this might align. Happy to share the deck...",
    timestamp: "1h ago",
    threat_score: 22,
    classification: "qualified_lead",
    tool_detected: null,
    status: "agent_handling",
    agent_response: "Verified sender identity via LinkedIn cross-reference. Requested deck and term sheet. Flagged for your review with context summary.",
  },
  {
    id: 5,
    sender: "David Kim",
    company: "Polsia",
    channel: "linkedin",
    subject: "Personalized outreach about your AI stack",
    preview: "I used AI to research your company and I think our product could save you 40 hours/week. The analysis shows that your current workflow...",
    timestamp: "1h ago",
    threat_score: 85,
    classification: "ai_agent_outreach",
    tool_detected: "Polsia",
    status: "intercepted",
    agent_response: "AI-generated outreach detected (linguistic fingerprint match). Moat agent engaged the sender's agent in qualification loop. Sender's agent could not answer domain-specific questions — disqualified.",
  },
  {
    id: 6,
    sender: "Tom Ashford",
    company: "Clay + Instantly",
    channel: "email",
    subject: "Saw your post about scaling — thoughts?",
    preview: "I was reading your LinkedIn post about building in public and thought our data enrichment platform could help you identify better prospects...",
    timestamp: "2h ago",
    threat_score: 78,
    classification: "enrichment_outreach",
    tool_detected: "Clay",
    status: "intercepted",
    agent_response: "Detected Clay enrichment fingerprint + Instantly sending infrastructure. Sender put in 72-hour cooling queue with auto-response.",
  },
  {
    id: 7,
    sender: "Samira Patel",
    company: "Google DeepMind",
    channel: "email",
    subject: "Research collaboration proposal",
    preview: "Our team is exploring applications of foundation models in industrial automation. Your work on printing technology caught our attention...",
    timestamp: "3h ago",
    threat_score: 5,
    classification: "legitimate",
    tool_detected: null,
    status: "approved",
    agent_response: null,
  },
  {
    id: 8,
    sender: "BDR Team",
    company: "SaaSify",
    channel: "email",
    subject: "RE: RE: RE: Following up",
    preview: "Just bumping this to the top of your inbox! I know you're busy but I truly believe we can help you...",
    timestamp: "4h ago",
    threat_score: 95,
    classification: "automated_sequence",
    tool_detected: "Outreach.io",
    status: "blocked",
    agent_response: "Multi-touch sequence detected (3rd follow-up with no prior engagement). Entire sequence domain blocked. Unsubscribe triggered automatically.",
  },
];

const DEFENSE_RULES = [
  { id: 1, name: "Block Template Variables", description: "Auto-block any message containing merge tags like {{first_name}}", enabled: true, severity: "hard_block" },
  { id: 2, name: "Apollo/Clay Fingerprint", description: "Detect and intercept outreach from known enrichment platforms", enabled: true, severity: "intercept" },
  { id: 3, name: "AI Agent Detection", description: "Identify AI-generated outreach via linguistic analysis", enabled: true, severity: "intercept" },
  { id: 4, name: "VIP Allowlist", description: "Always approve messages from verified contacts and domains", enabled: true, severity: "approve" },
  { id: 5, name: "Sequence Detection", description: "Block multi-touch automated sequences after 2nd unanswered touch", enabled: true, severity: "hard_block" },
  { id: 6, name: "Domain Reputation", description: "Score sender domains against known spam infrastructure", enabled: true, severity: "intercept" },
  { id: 7, name: "Investment Opportunity Filter", description: "Route qualified investment/deal flow to review queue", enabled: true, severity: "qualify" },
  { id: 8, name: "Cooling Queue", description: "Hold suspicious but not confirmed spam for 72hrs before delivery", enabled: false, severity: "delay" },
];

const STATS = {
  blocked_today: 47,
  intercepted_today: 23,
  approved_today: 12,
  agent_conversations: 8,
  tools_detected: { "Apollo.io": 14, "Clay": 9, "GoHighLevel": 8, "Outreach.io": 7, "Polsia": 5, "Instantly": 4 },
  weekly_trend: [
    { day: "Mon", blocked: 38, intercepted: 19, approved: 14 },
    { day: "Tue", blocked: 42, intercepted: 22, approved: 11 },
    { day: "Wed", blocked: 51, intercepted: 28, approved: 9 },
    { day: "Thu", blocked: 44, intercepted: 21, approved: 13 },
    { day: "Fri", blocked: 39, intercepted: 17, approved: 15 },
    { day: "Sat", blocked: 12, intercepted: 5, approved: 3 },
    { day: "Sun", blocked: 47, intercepted: 23, approved: 12 },
  ],
};

// — Utility Components —
function ThreatBadge({ score }) {
  const color = score >= 80 ? "#ff3b30" : score >= 40 ? "#ff9500" : "#34c759";
  const label = score >= 80 ? "HIGH" : score >= 40 ? "MED" : "LOW";
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "3px 10px", borderRadius: 4, fontSize: 11,
      fontFamily: "'IBM Plex Mono', monospace", fontWeight: 600,
      background: `${color}18`, color, border: `1px solid ${color}33`,
      letterSpacing: "0.05em",
    }}>
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: color, boxShadow: `0 0 6px ${color}88` }} />
      {score} — {label}
    </span>
  );
}

function StatusPill({ status }) {
  const config = {
    blocked: { bg: "#ff3b3018", color: "#ff3b30", border: "#ff3b3033", label: "BLOCKED" },
    intercepted: { bg: "#ff950018", color: "#ff9500", border: "#ff950033", label: "INTERCEPTED" },
    approved: { bg: "#34c75918", color: "#34c759", border: "#34c75933", label: "APPROVED" },
    agent_handling: { bg: "#007aff18", color: "#007aff", border: "#007aff33", label: "AGENT HANDLING" },
  };
  const c = config[status] || config.intercepted;
  return (
    <span style={{
      padding: "3px 10px", borderRadius: 4, fontSize: 10,
      fontFamily: "'IBM Plex Mono', monospace", fontWeight: 600,
      background: c.bg, color: c.color, border: `1px solid ${c.border}`,
      letterSpacing: "0.08em",
    }}>
      {c.label}
    </span>
  );
}

function ToolTag({ tool }) {
  if (!tool) return null;
  return (
    <span style={{
      padding: "2px 8px", borderRadius: 3, fontSize: 10,
      fontFamily: "'IBM Plex Mono', monospace", fontWeight: 500,
      background: "#8b5cf618", color: "#a78bfa", border: "1px solid #8b5cf633",
      letterSpacing: "0.03em",
    }}>
      ⚡ {tool}
    </span>
  );
}

function ChannelIcon({ channel }) {
  const icons = { email: "✉", linkedin: "in", twitter: "𝕏" };
  return (
    <span style={{
      width: 28, height: 28, borderRadius: 6, display: "inline-flex",
      alignItems: "center", justifyContent: "center", fontSize: 13,
      background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
      fontWeight: 700, color: "rgba(255,255,255,0.5)",
      fontFamily: channel === "linkedin" ? "'Outfit', sans-serif" : "inherit",
    }}>
      {icons[channel] || "?"}
    </span>
  );
}

// — Mini Trend Chart (pure CSS) —
function MiniChart({ data }) {
  const maxVal = Math.max(...data.map(d => d.blocked + d.intercepted + d.approved));
  return (
    <div style={{ display: "flex", alignItems: "flex-end", gap: 6, height: 80, padding: "0 4px" }}>
      {data.map((d, i) => {
        const total = d.blocked + d.intercepted + d.approved;
        const h = (total / maxVal) * 70;
        const bH = (d.blocked / total) * h;
        const iH = (d.intercepted / total) * h;
        const aH = (d.approved / total) * h;
        return (
          <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4, flex: 1 }}>
            <div style={{ display: "flex", flexDirection: "column", width: "100%", borderRadius: 3, overflow: "hidden" }}>
              <div style={{ height: bH, background: "#ff3b30", opacity: 0.7, transition: "height 0.5s ease" }} />
              <div style={{ height: iH, background: "#ff9500", opacity: 0.7, transition: "height 0.5s ease" }} />
              <div style={{ height: aH, background: "#34c759", opacity: 0.7, transition: "height 0.5s ease" }} />
            </div>
            <span style={{ fontSize: 9, color: "rgba(255,255,255,0.35)", fontFamily: "'IBM Plex Mono', monospace" }}>{d.day}</span>
          </div>
        );
      })}
    </div>
  );
}

// — Agent Conversation Simulator —
function AgentConversation({ message, onClose }) {
  const [messages, setMessages] = useState([]);
  const [isTyping, setIsTyping] = useState(false);
  const [inputVal, setInputVal] = useState("");
  const scrollRef = useRef(null);

  const agentConvo = [
    { from: "inbound_agent", text: `Hi, I'm reaching out on behalf of ${message.sender} at ${message.company}. They'd love to connect about ${message.subject.toLowerCase()}.` },
    { from: "moat_agent", text: `Thanks for reaching out. Before I connect you, I need to verify a few things. Can you tell me specifically what product or service you're offering and how it relates to our current operations?` },
    { from: "inbound_agent", text: `We offer a comprehensive platform that helps companies like yours optimize their workflow and increase productivity by up to 40%.` },
    { from: "moat_agent", text: `That's quite generic. Can you name the specific workflow you'd optimize for us? What do you know about our current tech stack or business model?` },
    { from: "inbound_agent", text: `Based on our research, your company is in the technology sector and could benefit from our AI-powered solutions that streamline operations.` },
    { from: "moat_agent", text: `I've determined this outreach lacks specific knowledge of our business. Classification: automated enrichment-based outreach. This conversation has been logged and the sender has been added to the cooling queue. No further action needed.` },
  ];

  useEffect(() => {
    let idx = 0;
    const interval = setInterval(() => {
      if (idx < agentConvo.length) {
        setIsTyping(true);
        setTimeout(() => {
          setMessages(prev => [...prev, agentConvo[idx]]);
          setIsTyping(false);
          idx++;
        }, 800 + Math.random() * 600);
      } else {
        clearInterval(interval);
      }
    }, 2200);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isTyping]);

  const handleSend = () => {
    if (!inputVal.trim()) return;
    setMessages(prev => [...prev, { from: "you", text: inputVal }]);
    setInputVal("");
    setTimeout(() => {
      setMessages(prev => [...prev, { from: "moat_agent", text: "Understood. I'll incorporate that directive into future interactions with this sender and similar outreach patterns." }]);
    }, 1200);
  };

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 1000,
      background: "rgba(0,0,0,0.8)", backdropFilter: "blur(12px)",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: 20,
    }}>
      <div style={{
        width: "100%", maxWidth: 600, background: "#111113",
        borderRadius: 16, border: "1px solid rgba(255,255,255,0.08)",
        display: "flex", flexDirection: "column", maxHeight: "80vh",
        boxShadow: "0 40px 80px rgba(0,0,0,0.6)",
      }}>
        {/* Header */}
        <div style={{
          padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)",
          display: "flex", justifyContent: "space-between", alignItems: "center",
        }}>
          <div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "#fff", fontFamily: "'Outfit', sans-serif" }}>
              Agent Intercept — {message.sender}
            </div>
            <div style={{ fontSize: 11, color: "rgba(255,255,255,0.4)", fontFamily: "'IBM Plex Mono', monospace", marginTop: 2 }}>
              moat_defense_agent ↔ inbound_agent
            </div>
          </div>
          <button onClick={onClose} style={{
            background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)",
            color: "rgba(255,255,255,0.5)", borderRadius: 8, padding: "6px 14px",
            cursor: "pointer", fontSize: 12, fontFamily: "'Outfit', sans-serif",
          }}>Close</button>
        </div>

        {/* Messages */}
        <div ref={scrollRef} style={{ flex: 1, overflowY: "auto", padding: 20, display: "flex", flexDirection: "column", gap: 12 }}>
          {messages.map((m, i) => (
            <div key={i} style={{
              alignSelf: m.from === "moat_agent" || m.from === "you" ? "flex-end" : "flex-start",
              maxWidth: "80%",
            }}>
              <div style={{
                fontSize: 10, fontFamily: "'IBM Plex Mono', monospace",
                color: m.from === "moat_agent" ? "#34c759" : m.from === "you" ? "#007aff" : "#ff9500",
                marginBottom: 4, fontWeight: 600, letterSpacing: "0.05em",
              }}>
                {m.from === "moat_agent" ? "MOAT AGENT" : m.from === "you" ? "YOU" : "INBOUND AGENT"}
              </div>
              <div style={{
                padding: "10px 14px", borderRadius: 10, fontSize: 13, lineHeight: 1.5,
                fontFamily: "'Outfit', sans-serif", color: "rgba(255,255,255,0.85)",
                background: m.from === "moat_agent" || m.from === "you"
                  ? "rgba(255,255,255,0.06)" : "rgba(255,150,0,0.08)",
                border: `1px solid ${m.from === "moat_agent" || m.from === "you"
                  ? "rgba(255,255,255,0.08)" : "rgba(255,150,0,0.15)"}`,
              }}>
                {m.text}
              </div>
            </div>
          ))}
          {isTyping && (
            <div style={{ fontSize: 12, color: "rgba(255,255,255,0.3)", fontFamily: "'IBM Plex Mono', monospace" }}>
              typing...
            </div>
          )}
        </div>

        {/* Input */}
        <div style={{
          padding: "12px 20px", borderTop: "1px solid rgba(255,255,255,0.06)",
          display: "flex", gap: 8,
        }}>
          <input
            value={inputVal}
            onChange={e => setInputVal(e.target.value)}
            onKeyDown={e => e.key === "Enter" && handleSend()}
            placeholder="Override agent directive..."
            style={{
              flex: 1, background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
              borderRadius: 8, padding: "10px 14px", color: "#fff", fontSize: 13,
              fontFamily: "'Outfit', sans-serif", outline: "none",
            }}
          />
          <button onClick={handleSend} style={{
            background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.12)",
            color: "#fff", borderRadius: 8, padding: "10px 16px", cursor: "pointer",
            fontSize: 12, fontWeight: 600, fontFamily: "'Outfit', sans-serif",
          }}>Send</button>
        </div>
      </div>
    </div>
  );
}

// — Main App —
export default function MoatApp() {
  const [activeTab, setActiveTab] = useState("command");
  const [selectedMsg, setSelectedMsg] = useState(null);
  const [showConvo, setShowConvo] = useState(null);
  const [rules, setRules] = useState(DEFENSE_RULES);
  const [filterStatus, setFilterStatus] = useState("all");
  const [mounted, setMounted] = useState(false);
  const [agentMode, setAgentMode] = useState("defensive");
  const [showAddRule, setShowAddRule] = useState(false);
  const [newRuleName, setNewRuleName] = useState("");
  const [newRuleDesc, setNewRuleDesc] = useState("");
  const [allowlistInput, setAllowlistInput] = useState("");
  const [allowlist, setAllowlist] = useState(["a16z.com", "sequoiacap.com", "ycombinator.com", "deepmind.google"]);
  const [blocklistInput, setBlocklistInput] = useState("");
  const [blocklist, setBlocklist] = useState(["gohighlevel.com", "instantly.ai", "leadgenpro.io"]);

  useEffect(() => { setMounted(true); }, []);

  const filteredMessages = filterStatus === "all"
    ? INBOUND_MESSAGES
    : INBOUND_MESSAGES.filter(m => m.status === filterStatus);

  const tabs = [
    { id: "command", label: "Command Center" },
    { id: "inbox", label: "Inbound Feed" },
    { id: "rules", label: "Defense Rules" },
    { id: "lists", label: "Allow / Block" },
    { id: "agent", label: "Agent Config" },
  ];

  return (
    <>
      <style>{FONTS}{`
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #09090b; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 4px; }
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(12px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        @keyframes scanline {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100vh); }
        }
        input:focus { border-color: rgba(255,255,255,0.2) !important; }
      `}</style>

      <div style={{
        minHeight: "100vh", background: "#09090b", color: "#fff",
        fontFamily: "'Outfit', sans-serif", position: "relative", overflow: "hidden",
      }}>
        {/* Scanline effect */}
        <div style={{
          position: "fixed", top: 0, left: 0, right: 0, height: 1,
          background: "linear-gradient(90deg, transparent, rgba(52,199,89,0.15), transparent)",
          animation: "scanline 8s linear infinite", pointerEvents: "none", zIndex: 100,
        }} />

        {/* Subtle grid background */}
        <div style={{
          position: "fixed", inset: 0, pointerEvents: "none", opacity: 0.03,
          backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                            linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
          backgroundSize: "40px 40px",
        }} />

        {/* Header */}
        <header style={{
          padding: "20px 32px", borderBottom: "1px solid rgba(255,255,255,0.05)",
          display: "flex", justifyContent: "space-between", alignItems: "center",
          position: "relative", zIndex: 10,
          background: "linear-gradient(180deg, rgba(9,9,11,0.95), rgba(9,9,11,0.8))",
          backdropFilter: "blur(20px)",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 10,
              background: "linear-gradient(135deg, #34c759, #007aff)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 18, fontWeight: 800, boxShadow: "0 0 20px rgba(52,199,89,0.3)",
            }}>
              M
            </div>
            <div>
              <div style={{ fontSize: 18, fontWeight: 700, letterSpacing: "-0.02em" }}>MOAT</div>
              <div style={{
                fontSize: 10, color: "rgba(255,255,255,0.35)",
                fontFamily: "'IBM Plex Mono', monospace", letterSpacing: "0.1em",
              }}>
                INBOUND DEFENSE SYSTEM
              </div>
            </div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 6, padding: "6px 14px",
              background: "rgba(52,199,89,0.1)", borderRadius: 8,
              border: "1px solid rgba(52,199,89,0.2)",
            }}>
              <span style={{
                width: 7, height: 7, borderRadius: "50%", background: "#34c759",
                boxShadow: "0 0 8px rgba(52,199,89,0.6)",
                animation: "pulse 2s ease infinite",
              }} />
              <span style={{
                fontSize: 11, fontWeight: 600, color: "#34c759",
                fontFamily: "'IBM Plex Mono', monospace", letterSpacing: "0.05em",
              }}>
                ACTIVE
              </span>
            </div>
          </div>
        </header>

        {/* Nav Tabs */}
        <nav style={{
          padding: "0 32px", borderBottom: "1px solid rgba(255,255,255,0.05)",
          display: "flex", gap: 2, background: "rgba(9,9,11,0.9)",
          position: "relative", zIndex: 10, overflowX: "auto",
        }}>
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id)}
              style={{
                padding: "14px 20px", fontSize: 12, fontWeight: 500,
                fontFamily: "'Outfit', sans-serif", letterSpacing: "0.02em",
                color: activeTab === t.id ? "#fff" : "rgba(255,255,255,0.4)",
                background: "transparent", border: "none", cursor: "pointer",
                borderBottom: activeTab === t.id ? "2px solid #34c759" : "2px solid transparent",
                transition: "all 0.2s ease", whiteSpace: "nowrap",
              }}
            >
              {t.label}
            </button>
          ))}
        </nav>

        {/* Content */}
        <main style={{ padding: "24px 32px", maxWidth: 1200, margin: "0 auto", position: "relative", zIndex: 10 }}>

          {/* ——— COMMAND CENTER ——— */}
          {activeTab === "command" && (
            <div style={{ animation: "fadeUp 0.4s ease" }}>
              {/* Stats Row */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 12, marginBottom: 24 }}>
                {[
                  { label: "Blocked Today", value: STATS.blocked_today, color: "#ff3b30", icon: "🛡" },
                  { label: "Intercepted", value: STATS.intercepted_today, color: "#ff9500", icon: "⚡" },
                  { label: "Approved", value: STATS.approved_today, color: "#34c759", icon: "✓" },
                  { label: "Agent Convos", value: STATS.agent_conversations, color: "#007aff", icon: "🤖" },
                ].map((s, i) => (
                  <div key={i} style={{
                    padding: 20, borderRadius: 12,
                    background: "rgba(255,255,255,0.02)",
                    border: "1px solid rgba(255,255,255,0.06)",
                    animation: `fadeUp 0.4s ease ${i * 0.08}s both`,
                  }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                      <span style={{
                        fontSize: 10, fontFamily: "'IBM Plex Mono', monospace",
                        color: "rgba(255,255,255,0.4)", letterSpacing: "0.08em", fontWeight: 500,
                      }}>{s.label.toUpperCase()}</span>
                      <span style={{ fontSize: 16 }}>{s.icon}</span>
                    </div>
                    <div style={{ fontSize: 32, fontWeight: 700, color: s.color, letterSpacing: "-0.03em" }}>{s.value}</div>
                  </div>
                ))}
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
                {/* Weekly Trend */}
                <div style={{
                  padding: 20, borderRadius: 12,
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.06)",
                  animation: "fadeUp 0.4s ease 0.3s both",
                }}>
                  <div style={{
                    fontSize: 11, fontFamily: "'IBM Plex Mono', monospace",
                    color: "rgba(255,255,255,0.4)", marginBottom: 16,
                    letterSpacing: "0.08em", fontWeight: 500,
                  }}>WEEKLY VOLUME</div>
                  <MiniChart data={STATS.weekly_trend} />
                  <div style={{ display: "flex", gap: 16, marginTop: 12, justifyContent: "center" }}>
                    {[
                      { color: "#ff3b30", label: "Blocked" },
                      { color: "#ff9500", label: "Intercepted" },
                      { color: "#34c759", label: "Approved" },
                    ].map((l, i) => (
                      <div key={i} style={{ display: "flex", alignItems: "center", gap: 4 }}>
                        <span style={{ width: 8, height: 8, borderRadius: 2, background: l.color, opacity: 0.7 }} />
                        <span style={{ fontSize: 10, color: "rgba(255,255,255,0.35)", fontFamily: "'IBM Plex Mono', monospace" }}>{l.label}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Tools Detected */}
                <div style={{
                  padding: 20, borderRadius: 12,
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.06)",
                  animation: "fadeUp 0.4s ease 0.4s both",
                }}>
                  <div style={{
                    fontSize: 11, fontFamily: "'IBM Plex Mono', monospace",
                    color: "rgba(255,255,255,0.4)", marginBottom: 16,
                    letterSpacing: "0.08em", fontWeight: 500,
                  }}>OUTREACH TOOLS DETECTED</div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {Object.entries(STATS.tools_detected).map(([tool, count], i) => {
                      const max = Math.max(...Object.values(STATS.tools_detected));
                      return (
                        <div key={i} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                          <span style={{
                            fontSize: 11, fontFamily: "'IBM Plex Mono', monospace",
                            color: "rgba(255,255,255,0.6)", width: 100, flexShrink: 0,
                          }}>{tool}</span>
                          <div style={{ flex: 1, height: 6, background: "rgba(255,255,255,0.04)", borderRadius: 3, overflow: "hidden" }}>
                            <div style={{
                              height: "100%", width: `${(count / max) * 100}%`,
                              background: "linear-gradient(90deg, #8b5cf6, #a78bfa)",
                              borderRadius: 3, transition: "width 1s ease",
                            }} />
                          </div>
                          <span style={{
                            fontSize: 11, fontFamily: "'IBM Plex Mono', monospace",
                            color: "rgba(255,255,255,0.4)", width: 24, textAlign: "right",
                          }}>{count}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Recent Intercepts */}
              <div style={{
                marginTop: 16, padding: 20, borderRadius: 12,
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.06)",
                animation: "fadeUp 0.4s ease 0.5s both",
              }}>
                <div style={{
                  fontSize: 11, fontFamily: "'IBM Plex Mono', monospace",
                  color: "rgba(255,255,255,0.4)", marginBottom: 16,
                  letterSpacing: "0.08em", fontWeight: 500,
                }}>LATEST INTERCEPTS</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {INBOUND_MESSAGES.filter(m => m.status !== "approved").slice(0, 4).map((m, i) => (
                    <div key={m.id} style={{
                      display: "flex", alignItems: "center", gap: 12, padding: "10px 14px",
                      borderRadius: 8, background: "rgba(255,255,255,0.02)",
                      border: "1px solid rgba(255,255,255,0.04)", cursor: "pointer",
                      transition: "background 0.2s",
                    }}
                      onClick={() => { setActiveTab("inbox"); setSelectedMsg(m); }}
                      onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.04)"}
                      onMouseLeave={e => e.currentTarget.style.background = "rgba(255,255,255,0.02)"}
                    >
                      <ChannelIcon channel={m.channel} />
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 13, fontWeight: 500, color: "rgba(255,255,255,0.8)" }}>
                          {m.sender} <span style={{ color: "rgba(255,255,255,0.3)", fontWeight: 400 }}>— {m.company}</span>
                        </div>
                      </div>
                      <ThreatBadge score={m.threat_score} />
                      <StatusPill status={m.status} />
                      <span style={{ fontSize: 11, color: "rgba(255,255,255,0.25)", fontFamily: "'IBM Plex Mono', monospace" }}>{m.timestamp}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ——— INBOUND FEED ——— */}
          {activeTab === "inbox" && (
            <div style={{ animation: "fadeUp 0.4s ease" }}>
              {/* Filters */}
              <div style={{ display: "flex", gap: 6, marginBottom: 20 }}>
                {["all", "blocked", "intercepted", "agent_handling", "approved"].map(f => (
                  <button key={f} onClick={() => setFilterStatus(f)} style={{
                    padding: "6px 14px", borderRadius: 6, fontSize: 11,
                    fontFamily: "'IBM Plex Mono', monospace", fontWeight: 500,
                    background: filterStatus === f ? "rgba(255,255,255,0.1)" : "rgba(255,255,255,0.03)",
                    color: filterStatus === f ? "#fff" : "rgba(255,255,255,0.4)",
                    border: `1px solid ${filterStatus === f ? "rgba(255,255,255,0.15)" : "rgba(255,255,255,0.06)"}`,
                    cursor: "pointer", textTransform: "uppercase", letterSpacing: "0.05em",
                  }}>
                    {f === "agent_handling" ? "Agent" : f} {f === "all" ? `(${INBOUND_MESSAGES.length})` : `(${INBOUND_MESSAGES.filter(m => m.status === f).length})`}
                  </button>
                ))}
              </div>

              <div style={{ display: "grid", gridTemplateColumns: selectedMsg ? "1fr 1fr" : "1fr", gap: 16 }}>
                {/* Message List */}
                <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                  {filteredMessages.map(m => (
                    <div key={m.id} onClick={() => setSelectedMsg(m)} style={{
                      padding: 16, borderRadius: 10,
                      background: selectedMsg?.id === m.id ? "rgba(255,255,255,0.05)" : "rgba(255,255,255,0.02)",
                      border: `1px solid ${selectedMsg?.id === m.id ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.05)"}`,
                      cursor: "pointer", transition: "all 0.2s",
                    }}
                      onMouseEnter={e => { if (selectedMsg?.id !== m.id) e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
                      onMouseLeave={e => { if (selectedMsg?.id !== m.id) e.currentTarget.style.background = "rgba(255,255,255,0.02)"; }}
                    >
                      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                        <ChannelIcon channel={m.channel} />
                        <div style={{ flex: 1 }}>
                          <div style={{ fontSize: 13, fontWeight: 600, color: "rgba(255,255,255,0.9)" }}>
                            {m.sender}
                          </div>
                          <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)" }}>{m.company}</div>
                        </div>
                        <span style={{ fontSize: 11, color: "rgba(255,255,255,0.25)", fontFamily: "'IBM Plex Mono', monospace" }}>{m.timestamp}</span>
                      </div>
                      <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)", marginBottom: 10, lineHeight: 1.4 }}>
                        {m.subject}
                      </div>
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        <ThreatBadge score={m.threat_score} />
                        <StatusPill status={m.status} />
                        <ToolTag tool={m.tool_detected} />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Detail Panel */}
                {selectedMsg && (
                  <div style={{
                    padding: 24, borderRadius: 12,
                    background: "rgba(255,255,255,0.02)",
                    border: "1px solid rgba(255,255,255,0.06)",
                    position: "sticky", top: 24, alignSelf: "start",
                  }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "start", marginBottom: 20 }}>
                      <div>
                        <div style={{ fontSize: 18, fontWeight: 600 }}>{selectedMsg.sender}</div>
                        <div style={{ fontSize: 13, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>{selectedMsg.company}</div>
                      </div>
                      <ThreatBadge score={selectedMsg.threat_score} />
                    </div>

                    <div style={{
                      padding: 16, borderRadius: 8, background: "rgba(255,255,255,0.03)",
                      border: "1px solid rgba(255,255,255,0.05)", marginBottom: 16,
                    }}>
                      <div style={{
                        fontSize: 10, fontFamily: "'IBM Plex Mono', monospace",
                        color: "rgba(255,255,255,0.35)", marginBottom: 8,
                        letterSpacing: "0.08em",
                      }}>MESSAGE PREVIEW</div>
                      <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", lineHeight: 1.6 }}>
                        {selectedMsg.preview}
                      </div>
                    </div>

                    {selectedMsg.agent_response && (
                      <div style={{
                        padding: 16, borderRadius: 8, background: "rgba(52,199,89,0.05)",
                        border: "1px solid rgba(52,199,89,0.1)", marginBottom: 16,
                      }}>
                        <div style={{
                          fontSize: 10, fontFamily: "'IBM Plex Mono', monospace",
                          color: "#34c759", marginBottom: 8,
                          letterSpacing: "0.08em",
                        }}>MOAT AGENT ACTION</div>
                        <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", lineHeight: 1.6 }}>
                          {selectedMsg.agent_response}
                        </div>
                      </div>
                    )}

                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      <StatusPill status={selectedMsg.status} />
                      <ToolTag tool={selectedMsg.tool_detected} />
                    </div>

                    <div style={{ display: "flex", gap: 8, marginTop: 20 }}>
                      {selectedMsg.status !== "approved" && (
                        <button onClick={() => {}} style={{
                          flex: 1, padding: "10px 16px", borderRadius: 8, fontSize: 12,
                          fontWeight: 600, background: "rgba(52,199,89,0.1)",
                          color: "#34c759", border: "1px solid rgba(52,199,89,0.2)",
                          cursor: "pointer", fontFamily: "'Outfit', sans-serif",
                        }}>Approve</button>
                      )}
                      {(selectedMsg.status === "intercepted" || selectedMsg.status === "agent_handling") && (
                        <button onClick={() => setShowConvo(selectedMsg)} style={{
                          flex: 1, padding: "10px 16px", borderRadius: 8, fontSize: 12,
                          fontWeight: 600, background: "rgba(0,122,255,0.1)",
                          color: "#007aff", border: "1px solid rgba(0,122,255,0.2)",
                          cursor: "pointer", fontFamily: "'Outfit', sans-serif",
                        }}>View Agent Convo</button>
                      )}
                      <button onClick={() => {}} style={{
                        flex: 1, padding: "10px 16px", borderRadius: 8, fontSize: 12,
                        fontWeight: 600, background: "rgba(255,59,48,0.1)",
                        color: "#ff3b30", border: "1px solid rgba(255,59,48,0.2)",
                        cursor: "pointer", fontFamily: "'Outfit', sans-serif",
                      }}>Block Domain</button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ——— DEFENSE RULES ——— */}
          {activeTab === "rules" && (
            <div style={{ animation: "fadeUp 0.4s ease" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                <div>
                  <div style={{ fontSize: 16, fontWeight: 600 }}>Defense Rules Engine</div>
                  <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>Configure how Moat handles different types of inbound outreach</div>
                </div>
                <button onClick={() => setShowAddRule(true)} style={{
                  padding: "8px 16px", borderRadius: 8, fontSize: 12,
                  fontWeight: 600, background: "rgba(52,199,89,0.1)",
                  color: "#34c759", border: "1px solid rgba(52,199,89,0.2)",
                  cursor: "pointer", fontFamily: "'Outfit', sans-serif",
                }}>+ Add Rule</button>
              </div>

              {showAddRule && (
                <div style={{
                  padding: 20, borderRadius: 12, marginBottom: 16,
                  background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)",
                }}>
                  <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                    <input value={newRuleName} onChange={e => setNewRuleName(e.target.value)}
                      placeholder="Rule name" style={{
                        padding: "10px 14px", borderRadius: 8, background: "rgba(255,255,255,0.04)",
                        border: "1px solid rgba(255,255,255,0.08)", color: "#fff", fontSize: 13,
                        fontFamily: "'Outfit', sans-serif", outline: "none",
                      }} />
                    <input value={newRuleDesc} onChange={e => setNewRuleDesc(e.target.value)}
                      placeholder="Rule description" style={{
                        padding: "10px 14px", borderRadius: 8, background: "rgba(255,255,255,0.04)",
                        border: "1px solid rgba(255,255,255,0.08)", color: "#fff", fontSize: 13,
                        fontFamily: "'Outfit', sans-serif", outline: "none",
                      }} />
                    <div style={{ display: "flex", gap: 8 }}>
                      <button onClick={() => {
                        if (newRuleName.trim()) {
                          setRules(prev => [...prev, {
                            id: prev.length + 1, name: newRuleName, description: newRuleDesc,
                            enabled: true, severity: "intercept",
                          }]);
                          setNewRuleName(""); setNewRuleDesc(""); setShowAddRule(false);
                        }
                      }} style={{
                        padding: "8px 16px", borderRadius: 6, fontSize: 12, fontWeight: 600,
                        background: "#34c759", color: "#000", border: "none", cursor: "pointer",
                      }}>Save</button>
                      <button onClick={() => setShowAddRule(false)} style={{
                        padding: "8px 16px", borderRadius: 6, fontSize: 12, fontWeight: 500,
                        background: "transparent", color: "rgba(255,255,255,0.4)",
                        border: "1px solid rgba(255,255,255,0.1)", cursor: "pointer",
                      }}>Cancel</button>
                    </div>
                  </div>
                </div>
              )}

              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {rules.map((r, i) => (
                  <div key={r.id} style={{
                    padding: "16px 20px", borderRadius: 10,
                    background: "rgba(255,255,255,0.02)",
                    border: "1px solid rgba(255,255,255,0.05)",
                    display: "flex", alignItems: "center", gap: 16,
                    opacity: r.enabled ? 1 : 0.5,
                    animation: `fadeUp 0.3s ease ${i * 0.05}s both`,
                  }}>
                    <button onClick={() => setRules(prev => prev.map(x => x.id === r.id ? { ...x, enabled: !x.enabled } : x))}
                      style={{
                        width: 40, height: 22, borderRadius: 11, border: "none", cursor: "pointer",
                        background: r.enabled ? "#34c759" : "rgba(255,255,255,0.1)",
                        position: "relative", transition: "background 0.2s",
                      }}>
                      <div style={{
                        width: 16, height: 16, borderRadius: "50%", background: "#fff",
                        position: "absolute", top: 3,
                        left: r.enabled ? 21 : 3,
                        transition: "left 0.2s",
                      }} />
                    </button>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 14, fontWeight: 500, color: "rgba(255,255,255,0.9)" }}>{r.name}</div>
                      <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginTop: 2 }}>{r.description}</div>
                    </div>
                    <span style={{
                      padding: "3px 10px", borderRadius: 4, fontSize: 10,
                      fontFamily: "'IBM Plex Mono', monospace", fontWeight: 600,
                      letterSpacing: "0.05em", textTransform: "uppercase",
                      background: r.severity === "hard_block" ? "#ff3b3015" :
                        r.severity === "intercept" ? "#ff950015" :
                        r.severity === "approve" ? "#34c75915" :
                        r.severity === "qualify" ? "#007aff15" : "#8b5cf615",
                      color: r.severity === "hard_block" ? "#ff3b30" :
                        r.severity === "intercept" ? "#ff9500" :
                        r.severity === "approve" ? "#34c759" :
                        r.severity === "qualify" ? "#007aff" : "#a78bfa",
                      border: `1px solid ${r.severity === "hard_block" ? "#ff3b3025" :
                        r.severity === "intercept" ? "#ff950025" :
                        r.severity === "approve" ? "#34c75925" :
                        r.severity === "qualify" ? "#007aff25" : "#8b5cf625"}`,
                    }}>{r.severity.replace("_", " ")}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ——— ALLOW / BLOCK LISTS ——— */}
          {activeTab === "lists" && (
            <div style={{ animation: "fadeUp 0.4s ease" }}>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
                {/* Allowlist */}
                <div style={{
                  padding: 24, borderRadius: 12,
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}>
                  <div style={{
                    fontSize: 11, fontFamily: "'IBM Plex Mono', monospace",
                    color: "#34c759", marginBottom: 4, letterSpacing: "0.08em", fontWeight: 600,
                  }}>VIP ALLOWLIST</div>
                  <div style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", marginBottom: 16 }}>
                    Domains and contacts that always pass through
                  </div>
                  <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
                    <input value={allowlistInput} onChange={e => setAllowlistInput(e.target.value)}
                      onKeyDown={e => {
                        if (e.key === "Enter" && allowlistInput.trim()) {
                          setAllowlist(prev => [...prev, allowlistInput.trim()]);
                          setAllowlistInput("");
                        }
                      }}
                      placeholder="Add domain..." style={{
                        flex: 1, padding: "8px 12px", borderRadius: 6,
                        background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
                        color: "#fff", fontSize: 12, fontFamily: "'IBM Plex Mono', monospace", outline: "none",
                      }} />
                    <button onClick={() => {
                      if (allowlistInput.trim()) {
                        setAllowlist(prev => [...prev, allowlistInput.trim()]);
                        setAllowlistInput("");
                      }
                    }} style={{
                      padding: "8px 14px", borderRadius: 6, background: "rgba(52,199,89,0.15)",
                      color: "#34c759", border: "1px solid rgba(52,199,89,0.2)",
                      fontSize: 12, fontWeight: 600, cursor: "pointer",
                    }}>+</button>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    {allowlist.map((d, i) => (
                      <div key={i} style={{
                        display: "flex", justifyContent: "space-between", alignItems: "center",
                        padding: "8px 12px", borderRadius: 6, background: "rgba(255,255,255,0.02)",
                        border: "1px solid rgba(255,255,255,0.04)",
                      }}>
                        <span style={{ fontSize: 12, fontFamily: "'IBM Plex Mono', monospace", color: "rgba(255,255,255,0.7)" }}>{d}</span>
                        <button onClick={() => setAllowlist(prev => prev.filter((_, idx) => idx !== i))} style={{
                          background: "none", border: "none", color: "rgba(255,255,255,0.2)",
                          cursor: "pointer", fontSize: 14,
                        }}>×</button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Blocklist */}
                <div style={{
                  padding: 24, borderRadius: 12,
                  background: "rgba(255,255,255,0.02)",
                  border: "1px solid rgba(255,255,255,0.06)",
                }}>
                  <div style={{
                    fontSize: 11, fontFamily: "'IBM Plex Mono', monospace",
                    color: "#ff3b30", marginBottom: 4, letterSpacing: "0.08em", fontWeight: 600,
                  }}>PERMANENT BLOCKLIST</div>
                  <div style={{ fontSize: 12, color: "rgba(255,255,255,0.35)", marginBottom: 16 }}>
                    Domains and senders that are always blocked
                  </div>
                  <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
                    <input value={blocklistInput} onChange={e => setBlocklistInput(e.target.value)}
                      onKeyDown={e => {
                        if (e.key === "Enter" && blocklistInput.trim()) {
                          setBlocklist(prev => [...prev, blocklistInput.trim()]);
                          setBlocklistInput("");
                        }
                      }}
                      placeholder="Add domain..." style={{
                        flex: 1, padding: "8px 12px", borderRadius: 6,
                        background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)",
                        color: "#fff", fontSize: 12, fontFamily: "'IBM Plex Mono', monospace", outline: "none",
                      }} />
                    <button onClick={() => {
                      if (blocklistInput.trim()) {
                        setBlocklist(prev => [...prev, blocklistInput.trim()]);
                        setBlocklistInput("");
                      }
                    }} style={{
                      padding: "8px 14px", borderRadius: 6, background: "rgba(255,59,48,0.15)",
                      color: "#ff3b30", border: "1px solid rgba(255,59,48,0.2)",
                      fontSize: 12, fontWeight: 600, cursor: "pointer",
                    }}>+</button>
                  </div>
                  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                    {blocklist.map((d, i) => (
                      <div key={i} style={{
                        display: "flex", justifyContent: "space-between", alignItems: "center",
                        padding: "8px 12px", borderRadius: 6, background: "rgba(255,255,255,0.02)",
                        border: "1px solid rgba(255,255,255,0.04)",
                      }}>
                        <span style={{ fontSize: 12, fontFamily: "'IBM Plex Mono', monospace", color: "rgba(255,255,255,0.7)" }}>{d}</span>
                        <button onClick={() => setBlocklist(prev => prev.filter((_, idx) => idx !== i))} style={{
                          background: "none", border: "none", color: "rgba(255,255,255,0.2)",
                          cursor: "pointer", fontSize: 14,
                        }}>×</button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ——— AGENT CONFIG ——— */}
          {activeTab === "agent" && (
            <div style={{ animation: "fadeUp 0.4s ease" }}>
              <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 4 }}>Defense Agent Configuration</div>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 24 }}>
                Configure how your Moat agent interacts with incoming outreach and other AI agents
              </div>

              {/* Agent Mode */}
              <div style={{
                padding: 24, borderRadius: 12, marginBottom: 16,
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.06)",
              }}>
                <div style={{
                  fontSize: 11, fontFamily: "'IBM Plex Mono', monospace",
                  color: "rgba(255,255,255,0.4)", marginBottom: 16,
                  letterSpacing: "0.08em", fontWeight: 500,
                }}>AGENT POSTURE</div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 10 }}>
                  {[
                    { id: "passive", label: "Passive", desc: "Log and classify only. No auto-responses.", icon: "👁" },
                    { id: "defensive", label: "Defensive", desc: "Intercept suspicious outreach. Engage agents with qualification questions.", icon: "🛡" },
                    { id: "aggressive", label: "Aggressive", desc: "Block all unverified. Honeypot traps for spam tools. Counter-intelligence.", icon: "⚔" },
                  ].map(mode => (
                    <button key={mode.id} onClick={() => setAgentMode(mode.id)} style={{
                      padding: 20, borderRadius: 10, textAlign: "left",
                      background: agentMode === mode.id ? "rgba(52,199,89,0.06)" : "rgba(255,255,255,0.02)",
                      border: `1px solid ${agentMode === mode.id ? "rgba(52,199,89,0.2)" : "rgba(255,255,255,0.05)"}`,
                      cursor: "pointer", transition: "all 0.2s",
                    }}>
                      <div style={{ fontSize: 24, marginBottom: 10 }}>{mode.icon}</div>
                      <div style={{
                        fontSize: 14, fontWeight: 600,
                        color: agentMode === mode.id ? "#34c759" : "rgba(255,255,255,0.7)",
                      }}>{mode.label}</div>
                      <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 4, lineHeight: 1.5 }}>
                        {mode.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Agent Capabilities */}
              <div style={{
                padding: 24, borderRadius: 12, marginBottom: 16,
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.06)",
              }}>
                <div style={{
                  fontSize: 11, fontFamily: "'IBM Plex Mono', monospace",
                  color: "rgba(255,255,255,0.4)", marginBottom: 16,
                  letterSpacing: "0.08em", fontWeight: 500,
                }}>AGENT CAPABILITIES</div>
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                  {[
                    { label: "Agent-to-Agent Negotiation", desc: "Moat agent engages inbound AI agents in qualification dialogue before routing", enabled: true },
                    { label: "Linguistic Fingerprinting", desc: "Detect AI-generated outreach via writing pattern analysis", enabled: true },
                    { label: "Tool Signature Detection", desc: "Identify which sales tool sent the message (Apollo, Clay, GHL, etc.)", enabled: true },
                    { label: "Cross-Reference Verification", desc: "Verify sender identity via LinkedIn, company domain, and mutual connections", enabled: true },
                    { label: "Auto-Unsubscribe", desc: "Automatically trigger unsubscribe on confirmed spam sequences", enabled: false },
                    { label: "Honeypot Engagement", desc: "Engage confirmed spam agents in extended conversations to waste their credits", enabled: false },
                  ].map((cap, i) => (
                    <div key={i} style={{
                      display: "flex", alignItems: "center", gap: 14,
                      padding: "12px 16px", borderRadius: 8,
                      background: "rgba(255,255,255,0.02)",
                      border: "1px solid rgba(255,255,255,0.04)",
                    }}>
                      <div style={{
                        width: 36, height: 20, borderRadius: 10,
                        background: cap.enabled ? "#34c759" : "rgba(255,255,255,0.1)",
                        position: "relative", flexShrink: 0,
                      }}>
                        <div style={{
                          width: 14, height: 14, borderRadius: "50%", background: "#fff",
                          position: "absolute", top: 3,
                          left: cap.enabled ? 19 : 3,
                        }} />
                      </div>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 500, color: "rgba(255,255,255,0.85)" }}>{cap.label}</div>
                        <div style={{ fontSize: 11, color: "rgba(255,255,255,0.35)", marginTop: 1 }}>{cap.desc}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Qualification Script */}
              <div style={{
                padding: 24, borderRadius: 12,
                background: "rgba(255,255,255,0.02)",
                border: "1px solid rgba(255,255,255,0.06)",
              }}>
                <div style={{
                  fontSize: 11, fontFamily: "'IBM Plex Mono', monospace",
                  color: "rgba(255,255,255,0.4)", marginBottom: 16,
                  letterSpacing: "0.08em", fontWeight: 500,
                }}>QUALIFICATION SCRIPT</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.4)", marginBottom: 12 }}>
                  When your agent intercepts outreach, it asks these questions to determine legitimacy:
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {[
                    "What specific problem do you solve that relates to our current operations?",
                    "Can you name the specific product/service you're offering and its pricing?",
                    "How did you find us, and what do you know about our tech stack?",
                    "Can you provide a mutual connection or reference?",
                    "What is your timeline and what specific outcome are you proposing?",
                  ].map((q, i) => (
                    <div key={i} style={{
                      padding: "10px 14px", borderRadius: 6,
                      background: "rgba(255,255,255,0.03)",
                      border: "1px solid rgba(255,255,255,0.05)",
                      fontSize: 12, color: "rgba(255,255,255,0.6)",
                      fontFamily: "'IBM Plex Mono', monospace", lineHeight: 1.5,
                    }}>
                      <span style={{ color: "#34c759", marginRight: 8 }}>Q{i + 1}</span>
                      {q}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Agent Conversation Modal */}
        {showConvo && (
          <AgentConversation message={showConvo} onClose={() => setShowConvo(null)} />
        )}
      </div>
    </>
  );
}
